/*	
 *	C++ Reflection Framework.
 *
 *	Copyright (c) 2004,2005 - Fabio Lombardelli (lombarde@users.sf.net).
 *	The author makes no representations about the suitability of this software
 *	for any purpose. It is provided "as is" without express or implied warranty.
 *
 */

#ifndef REFLECT_DYN_CLASS_H
#define REFLECT_DYN_CLASS_H

#include "Reflect.h"

//#define REFLECT_BEGIN( name ) \
//	namespace Reflect \
//	{ \
//		template <> \
//		class ClassTypeImpl<name> \
//			:	public ClassTypeTmpl<name>, \
//				public Singleton<ClassTypeImpl<name> > \
//		{ \
//			friend class Singleton<ClassTypeImpl<name> >; \
//		private: \
//			ClassTypeImpl<name>() \
//				:	ClassTypeTmpl<Person>(#name), \
//					Singleton<ClassTypeImpl<name> >() \
//			{
//
//#define REFLECT_END \
//	} }; }

namespace Reflect
{

	class DynClassType;

	class DynObjHolder : public ObjHolder
	{
	public:
		DynObjHolder(const DynClassType* type);
		~DynObjHolder();

		void releaseContent() const;
		const Type& type() const;
		std::string toString() const;
		ObjHolder* deref() const;
		void* getRaw() const;
		
	private:
		const DynClassType* _type;
		std::vector<ObjHolder*> _instance;
	};

	class DynField
	{
	public:
		DynField(const std::string& name, const DynClassType* type);
		const std::string& name() const;
		const DynClassType* type() const;

	private:
		std::string _name;
		const DynClassType* _type;
	};

	class DynClassType : public Type
	{
	public:
		friend class DynObjHolder;

		DynClassType(const std::string& name);

		void add(const Field* field);
		void add(const DynField* field);

		virtual bool isBuiltin() const;
		virtual bool isClass() const;
		virtual bool isPointer() const;

		virtual ObjHolder* newInstance() const;
		virtual int size(ObjHolder* obj) const;
		virtual void store(ObjHolder* obj, Serialization::OutArchive* dst) const;
		virtual void fetch(ObjHolder* obj, Serialization::InArchive* src) const;

		virtual int size(ObjHolder* obj, Serialization::Aux::ObjectRegistry*) const;
		virtual void store(ObjHolder* obj, Serialization::OutArchive* dst, Serialization::Aux::ObjectRegistry*) const;
		virtual void fetch(ObjHolder* obj, Serialization::InArchive* src, Serialization::Aux::ObjectRegistry*) const;

	private:
		std::vector<const Field*> _fields;
		std::vector<const DynField*> _dynfields;
	};

} // namespace Reflect

#endif

