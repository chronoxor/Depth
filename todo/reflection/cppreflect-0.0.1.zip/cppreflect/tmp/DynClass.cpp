/*	
 *	C++ Reflection Framework.
 *
 *	Copyright (c) 2004,2005 - Fabio Lombardelli (lombarde@users.sf.net).
 *	The author makes no representations about the suitability of this software
 *	for any purpose. It is provided "as is" without express or implied warranty.
 *
 */

#include <DynClass.h>

namespace Reflect
{

	DynObjHolder::DynObjHolder(const DynClassType* type)
			:	_type(type)
	{
		unsigned i = 0;
		for (unsigned idx = 0; idx < _type->_fields.size(); idx++)
		{
			_instance.push_back(_type->_fields[0]->type().newInstance());
			i++;
		}
		for (unsigned idx = 0; idx < _type->_dynfields.size(); idx++)
		{
			_instance.push_back(_type->_dynfields[0]->type()->newInstance());
			i++;
		}
	}

	DynObjHolder::~DynObjHolder()
	{
		
	}

	void DynObjHolder::releaseContent() const
	{
		for (unsigned i = 0; i < _instance.size(); ++i) delete _instance[i];
	}

	const Type& DynObjHolder::type() const
	{
		return *_type;
	}

	std::string DynObjHolder::toString() const
	{
		return "";
	}

	ObjHolder* DynObjHolder::deref() const
	{
		return 0;
	}

	void* DynObjHolder::getRaw() const
	{
		return 0;
	}

	DynField::DynField(const std::string& name, const DynClassType* type)
		:	_name(name), _type(type)
	{
	
	}

	const std::string& DynField::name() const
	{
		return _name;
	}

	const DynClassType* DynField::type() const
	{
		return _type;
	}

	DynClassType::DynClassType(const std::string& name)
		:	Type(name)
	{
	
	}

	void DynClassType::add(const Field* field) 
	{
		_fields.push_back(field);
	}

	void DynClassType::add(const DynField* field) 
	{ 
		_dynfields.push_back(field);
	}

	bool DynClassType::isBuiltin() const { return false; }
	bool DynClassType::isClass() const { return false; }
	bool DynClassType::isPointer() const { return false; }

	ObjHolder* DynClassType::newInstance() const 
	{ 
		unsigned i = 0;
		DynObjHolder* obj = new DynObjHolder(this);
		return obj;
	}

	int DynClassType::size(ObjHolder* obj) const { return 0; }
	void DynClassType::store(ObjHolder* obj, Serialization::OutArchive* dst) const { return; }
	void DynClassType::fetch(ObjHolder* obj, Serialization::InArchive* src) const { return; }

	int DynClassType::size(ObjHolder* obj, Serialization::Aux::ObjectRegistry*) const { return 0; }
	void DynClassType::store(ObjHolder* obj, Serialization::OutArchive* dst, Serialization::Aux::ObjectRegistry*) const { return; }
	void DynClassType::fetch(ObjHolder* obj, Serialization::InArchive* src, Serialization::Aux::ObjectRegistry*) const { return; }

} // namespace Reflect
