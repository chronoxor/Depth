#ifndef STATIC_REFLECT_H
#define STATIC_REFLECT_H

#include <FLib/TypeList.h>

template <
	char* _name,
	typename _Type, 
	typename _FieldList = FLib::NullType, 
	typename _ClassList = FLib::NullType
>
class TypeInfo
{
public:
	inline static const char* name() { return _name; }

	typedef _Type Type;
	typedef _FieldList FieldList;
	typedef _ClassList ClassList;
};

template <
	char* _name,
	typename _ClassType,
	typename _FieldType,
	_FieldType _ClassType::* _data
>
class FieldInfo
{
public:
	inline static const char* name() { return _name; }

	typedef _ClassType ClassType;
	typedef _FieldType FieldType;
	
	static inline _FieldType _ClassType::* data() { return _data; }
};

/*test:*/

/*
	namespace _FilmHelper {
		char className[] = "Film";
		char field0[] = "_title";
		char field1[] = "_director";
		char field2[] = "_year";
	}

	typedef FieldInfo<_FilmHelper::field0, Film, std::string, &Film::_title> _FilmFieldInfo0;
	typedef FieldInfo<_FilmHelper::field1, Film, std::string, &Film::_director> _FilmFieldInfo1;
	typedef FieldInfo<_FilmHelper::field2, Film, int, &Film::_year> _FilmFieldInfo2;
	typedef TYPELIST_3(_FilmFieldInfo0, _FilmFieldInfo1, _FilmFieldInfo2) _FilmFieldList;
	typedef TypeInfo<_FilmHelper::className, Film, _FilmFieldList> _FilmTypeInfo;

	Film film("Pinco", "Palla", 123);
	cout << film.*FLib::TypeAt<_FilmTypeInfo::FieldList, 0>::Result::data() << endl;
	cout << film.*FLib::TypeAt<_FilmTypeInfo::FieldList, 1>::Result::data() << endl;
	cout << film.*FLib::TypeAt<_FilmTypeInfo::FieldList, 2>::Result::data() << endl;

*/

#endif
