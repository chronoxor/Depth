/*!
 *  \file    CClassFunctorX.hpp Class functor class emulates an object that
 *           can be called as a class method with 'operator()'.
 *  \brief   Class functor class.
 *  \author  Ivan Shynkarenka aka 4ekucT
 *  \version 1.0
 *  \date    10.05.2006
 */
/*==========================================================================*/
/*
    FILE DESCRIPTION: Class functor class.

    AUTHOR:    Ivan Shynkarenka aka 4ekucT
    GROUP:     The NULL workgroup
    PROJECT:   The Depth
    PART:      Functors definitions
    VERSION:   1.0
    CREATED:   10.05.2006 11:04:31

    EMAIL:     Depth@4enet.by
    WWW:       http://depth.belmt.com

    COPYRIGHT: (C) 2005-2007 The NULL workgroup. All Rights Reserved.
*/
/*--------------------------------------------------------------------------*/
/*
    Copyright (C) 2005-2007 The NULL workgroup.

    This program is free software; you can redistribute it  and/or  modify  it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your  option)
    any later version.

    This program is distributed in the  hope  that  it  will  be  useful,  but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE. See the GNU  General  Public  License
    for more details.

    You should have received a copy of the GNU General  Public  License  along
    with this program; if not, write to the Free Software Foundation, Inc., 59
    Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
/*--------------------------------------------------------------------------*/
/*
    FILE ID: $Id$

    CHANGE LOG:

    $Log$
*/
/*==========================================================================*/
#ifndef __CCLASSFUNCTORX_HPP__
#define __CCLASSFUNCTORX_HPP__
/*==========================================================================*/
#include <Depth/include/functors/CClassFunctor0.hpp>
/*==========================================================================*/
/* NAMESPACE DECLARATIONS                                                   */
/*==========================================================================*/
namespace NDepth {
/*--------------------------------------------------------------------------*/
namespace NFunctors {
/*==========================================================================*/
/* CLASS DECLARATIONS                                                       */
/*==========================================================================*/
//! Class functor class.
/*!
    Class functor is an object,  that  emulates  class  method  call.  It  has
    'operator()' so you can use  this  objects  in  various  algorithm.  Class
    functor object can be initialized with a  class  method  or  with  another
    functor.

    Note that before using functor it must be initialized. To check initialize
    state  you  can  use  'CClassFunctor::isValid()'  method.   If   you   use
    uninitialized functor it leads to the error.
*/
template <typename T_Method, class T_Allocator = NMemory::NAllocators::CAllocatorMemory>
class CClassFunctor :
  public NDetails::CClassFunctorHelper<T_Method, T_Allocator>
{
  //! Type for MConceptAnyMethod constraint checking.
  typedef T_Method TAnyMethodCheckType;
  //! Type for MConceptIAllocator constraint checking.
  typedef T_Allocator TAllocatorCheckType;
  //! Type for MConceptSwappable constraint checking.
  typedef CClassFunctor<T_Method, T_Allocator> TSwappableCheckType;

  // Check T_Method class constraint to be an any class method declaration.
  REQUIRES_CONCEPT1(NConcept::NFunctions, MConceptAnyMethod, TAnyMethodCheckType);
  // Check T_Allocator template argument constraint to be a memory allocator.
  REQUIRES_CONCEPT1(NConcept::NTypes, MConceptIAllocator, TAllocatorCheckType);
  // Check CClassFunctor class constraint to be a swappable class.
  REQUIRES_CONCEPT1(NConcept::NClass, MConceptSwappable, TSwappableCheckType);

public:
  //! Empty functor.
  using NDetails::CClassFunctorHelper<T_Method, T_Allocator>::e_EMPTY;
  //! Functor initialized with the class method.
  using NDetails::CClassFunctorHelper<T_Method, T_Allocator>::e_METHOD;
  //! Functor initialized with the class constant method.
  using NDetails::CClassFunctorHelper<T_Method, T_Allocator>::e_METHOD_CONST;
  //! Functor initialized with the class volatile method.
  using NDetails::CClassFunctorHelper<T_Method, T_Allocator>::e_METHOD_VOLATILE;
  //! Functor initialized with the class constant volatile method.
  using NDetails::CClassFunctorHelper<T_Method, T_Allocator>::e_METHOD_CONST_VOLATILE;

  //! Type of the functor.
  typedef typename NDetails::CClassFunctorHelper<T_Method, T_Allocator>::EFunctorType EFunctorType;
  //! Functor class method type.
  typedef typename NDetails::CClassFunctorHelper<T_Method, T_Allocator>::TMethod TMethod;
  //! Functor allocator type.
  typedef T_Allocator TAllocator;

  //! Default class constructor.
  /*!
      \param a_crAllocator - Constant reference to the memory allocator (default is T_Allocator()).
  */
  CClassFunctor(const T_Allocator& a_crAllocator = T_Allocator());
  //! Class constructor with setting functor class method.
  /*!
      Initialize current functor with suitable pointer to class method.  After
      this initializing you can safely call 'operator()'.

      \param a_fMethod - Pointer to the class method.
      \param a_crAllocator - Constant reference to the memory allocator (default is T_Allocator()).
  */
  CClassFunctor(TMethod a_fMethod, const T_Allocator& a_crAllocator = T_Allocator());
  //! Class copy constructor.
  /*!
      \param a_crInstance - Constant reference to another instance of the CClassFunctor class.
      \param a_crAllocator - Constant reference to the memory allocator (default is T_Allocator()).
  */
  CClassFunctor(const CClassFunctor<T_Method, T_Allocator>& a_crInstance, const T_Allocator& a_crAllocator = T_Allocator());
  //! Class destructor.
  virtual ~CClassFunctor();

  //! Operator: Equal to another CClassFunctor class instance.
  /*!
      \param a_crInstance1 - Constant reference to the current instance of the CClassFunctor class.
      \param a_crInstance2 - Constant reference to another instance of the CClassFunctor class.
      \return true  - if CClassFunctor class instance is equal to another one. \n
              false - if CClassFunctor class instance is not equal to another one. \n
  */
  template <typename T_OtherClassRoutine, class T_OtherAllocator>
  friend Tbool operator == (const CClassFunctor<T_OtherClassRoutine, T_OtherAllocator>& a_crInstance1, const CClassFunctor<T_OtherClassRoutine, T_OtherAllocator>& a_crInstance2);
  //! Operator: Not equal to another CClassFunctor class instance.
  /*!
      \param a_crInstance1 - Constant reference to the current instance of the CClassFunctor class.
      \param a_crInstance2 - Constant reference to another instance of the CClassFunctor class.
      \return true  - if CClassFunctor class instance is not equal to another one. \n
              false - if CClassFunctor class instance is equal to another one. \n
  */
  template <typename T_OtherClassRoutine, class T_OtherAllocator>
  friend Tbool operator != (const CClassFunctor<T_OtherClassRoutine, T_OtherAllocator>& a_crInstance1, const CClassFunctor<T_OtherClassRoutine, T_OtherAllocator>& a_crInstance2);

  //! Operator: Assign with class method.
  /*!
      \param a_fMethod - Pointer to the class method.
      \return Reference to the current class instance.
  */
  CClassFunctor<T_Method, T_Allocator>& operator = (TMethod a_fMethod);
  //! Operator: Assign another CClassFunctor class instance.
  /*!
      \param a_crInstance - Constant reference to another instance of the CClassFunctor class.
      \return Reference to the current class instance.
  */
  CClassFunctor<T_Method, T_Allocator>& operator = (const CClassFunctor<T_Method, T_Allocator>& a_crInstance);

  //! Set functor class method.
  /*!
      \param a_fMethod - Pointer to the class method.
      \return true  - if functor was successfully initialized with class method. \n
              false - if functor was not successfully initialized with class method. \n
  */
  Tbool set(TMethod a_fMethod);
  //! Set another CClassFunctor class instance.
  /*!
      \param a_crInstance - Constant reference to another instance of the CClassFunctor class.
      \return true  - if functor was successfully initialized with another functor. \n
              false - if functor was not successfully initialized with another functor. \n
  */
  Tbool set(const CClassFunctor<T_Method, T_Allocator>& a_crInstance);

  //! Get type of the current functor.
  /*!
      \return Type of the current functor.
  */
  EFunctorType getType() const;

  //! Clear current functor instance.
  /*!
      \return true  - if functor was successfully cleared. \n
              false - if functor was not successfully cleared. \n
  */
  Tbool clear();

  //! Swap two CClassFunctor class instances.
  /*!
      \param a_rInstance - Reference to another CClassFunctor class instance.
  */
  void swap(CClassFunctor<T_Method, T_Allocator>& a_rInstance);
};
/*==========================================================================*/
}
/*--------------------------------------------------------------------------*/
}
/*==========================================================================*/
#include <Depth/include/functors/CClassFunctorX.inl>
/*==========================================================================*/
#endif
